import Board from './Broad';
import './App.css';

function App() {   
  return (
    <>
     <Board/> 
    </>
  )
}

export default App;